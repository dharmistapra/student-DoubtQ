import React from 'react'

const Reviews = () => {

  return (
    <div>Reviews</div>
  )

}

export default Reviews;